import React from "react";
import { render } from "react-dom";
import { makeData, Logo, Tips } from "./utils";
import axios from 'axios';    
import DropDownComponent from "./components/DropDownComponent";

// Import React Table
import ReactTable from "react-table";
import "react-table/react-table.css";

class App extends React.Component {
  constructor() {
    super();
    this.state = {
      data: [],
      pages:0,
      loading: false,

    };
      
  }
   getTestData(page, pageSize, handleRetrievedData) {
        let url = 'http://localhost:8080/api/taskExecutionList?page='+page+'&size='+pageSize+'';

        return axios.get(url).then(response => handleRetrievedData(response)).catch(response => console.log(response));
    }
     handleSetData = data => {
    console.log(data);
    this.setState({ data: data });
  };
  render() {
    const { data } = this.state;
    return (
      <div>
        <DropDownComponent
          data={data}
          handleSetData={this.handleSetData}
        />
        <ReactTable
          data={data}
          pages={this.state.pages}
          columns={[
                  {
                      Header: "id",
                      accessor: "id",
                    },
                    {
                      Header: "CreationDate",
                      accessor: "creationDate"
                    },
                    {
                      Header: "TaskConfigName",
                      accessor: "taskConfigName"
                    },
                    {
                      Header: "DurationInSeconds",
                      accessor: "durationInSeconds"
                    },
                    
                  ]}
          loading={this.state.loading}
          pageSizeOptions={[2,4,6,8,10]}
          defaultPageSize={2}
          showPagination={true}
          className="-striped -highlight"
          onFetchData={(state, instance) => {
                             this.setState({loading: true});
                             this.getTestData(state.page, state.pageSize, (res) => {
                             this.setState({
                                     data: res.data.content,
                                     pages: res.data.totalElements,
                                     loading: false
                             })
                     });
                     }
                     }
        />
        <br />
      </div>
    );
  }
}
export default App;
render(<App />, document.getElementById("root"));
