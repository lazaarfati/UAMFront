import React from "react";
import ReactTable from "react-table";
import "react-table/react-table.css";
import axios from 'axios';    
class Table extends React.Component {
   constructor() {
       super();
       this.state = {
          data: [,],
          loading: false,
          pages: 0
       };
       this.getTestData =this.getTestData.bind(this);
   }
 
    
    getTestData(page, pageSize, sorted, filtered, handleRetrievedData) {
        let url = 'http://localhost:8080/api/taskExecutionList?page='+page+'&size='+pageSize+'';

        return axios.get(url).then(response => handleRetrievedData(response)).catch(response => console.log(response));
    }
    render() {
          return (
                  <ReactTable
                       data={this.state.data}
                       pages={this.state.pages}
                       defaultSorted={[
            {
              id: "age",
              desc: true
            }
          ]}
                       columns={[
                            {
                               Header: "id",
                               accessor: "id",
                             },
                             {
                               Header: "CreationDate",
                               accessor: "creationDate"
                             },
                             {
                               Header: "TaskConfigName",
                               accessor: "taskConfigName"
                             },
                             {
                               Header: "DurationInSeconds",
                               accessor: "durationInSeconds"
                              },
                              
                            ]}
                     defaultPageSize={2}
                     className="-striped -highlight"
                     loading={this.state.loading}
                     showPagination={true}
                     showPaginationTop={false}
                  
                    //  sortable={true}
                    // filterable={false}
                     showPaginationBottom={true}
                     pageSizeOptions={[2,4,6,8,10]}
                     manual // this would indicate that server side pagination has been enabled 
                     onFetchData={(state, instance) => {
                             this.setState({loading: true});
                             this.getTestData(state.page, state.pageSize, state.sorted, state.filtered, (res) => {
                             this.setState({
                                     data: res.data.content,
                                     pages: res.data.totalElements,
                                     loading: false
                             })
                     });
                     }
                     }
                     />
         );
     }
}
export default Table;
